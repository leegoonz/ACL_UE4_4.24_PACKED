#include "catch_interfaces_capture.h"

namespace Catch {
    IResultCapture::~IResultCapture() = default;
}
