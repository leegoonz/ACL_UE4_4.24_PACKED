# Documentation

*  [API and other conventions](api_conventions.md)
*  [Types supported](types_supported.md)
*  [SIMD support](simd_support.md)
*  [Handling asserts](handling_asserts.md)
*  [Getting started](getting_started.md)
